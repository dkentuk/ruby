# Hello world program by david kent 

puts "Hellow World"