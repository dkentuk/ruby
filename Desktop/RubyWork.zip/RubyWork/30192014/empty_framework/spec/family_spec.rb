describe "The Family Member Class" do
    it "should inherit from person" do
        #Parent
         p_parent = Person.new("joe", "bloggs", "1 Jan 1990")
        #Child
        c_fm = FamilyMember.new("Babby", "brooks", "8 Mar 1967")
        
        expect(c_fm.is_a? Person)
        

        
#        
#    it 'should do something else' do
#        expect(true).to eq true
    end
end