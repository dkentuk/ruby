#program that will ask you for your first and last name before welcoming the peson

puts 'Please enter first name: '
first_name = gets.chomp
puts 'Please enter last name: '
last_name = gets.chomp
puts 'Welcome to ruby ' + first_name + ' ' + last_name
