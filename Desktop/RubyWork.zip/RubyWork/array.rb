#languages = ['English', 'French', 'Norwegian', 'Ruby']
#
#languages.each do |lang|
#    puts 'I love ' + lang.to_s
#end
#
#12.times do
#    puts 'Hello'
#end
#
##gets amount of objecys within the arra
## puts languages.length 
##
## puts languages.join " , "
#
##puts languages.length
##
##newlangs = ["Japanses","Jave"]
##
##puts output.to_s
#
## insertion operator, adds it into the array
#newlangs << "Python"ee
#
##puts newlangs.to_s
### Sorts alphabetically
##put languages.sort
### prints the last object in the array
##puts languages.last
#

arr = [1, 2, 3, 4, 5, 6]
#arr.push(5) 
#arr << 6
arr.pop
arr.delete_at(2)
puts arr