# Test File

puts (9 / 2) * 5 + 3 - (2 +3) * 5
