input = gets.chomp.to_i
case input
when 1,2,3 then puts '1, 2, or 3'
when 10 then    puts '10'
else
    puts 'Some other number'
    puts 'another number'
end